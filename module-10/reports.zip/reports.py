import os
import mysql.connector
import reportlab
from mysql.connector import errorcode
from reportlab.lib.pagesizes import letter
from reportlab. pdfgen import canvas
from dotenv import dotenv_values
secrets = dotenv_values("c:/csd/csd-310/module-9/.env")
config = {
    "user": secrets["USER"],
    "password": secrets["PASSWORD"],
    "host": secrets["HOST"],
    "database": secrets["DATABASE"],
    "raise_on_warnings": True

}

def create_pdf_report(filename):
   c = canvas.Canvas(filename, pagesize=letter)
   header = 750
   c.drawString(150, header, "Suppliers Delivery Variances")
   for lines in x:
        header = header-20
        c.drawString(100, header, lines)
   header = header-50
   c.drawString(150, header, "Total Wine Sales by Distributor")
   for lines in y:
        header = header-20
        c.drawString(100, header, lines)
   header = header - 50
   c.drawString(150, header, "Employee Hours in 2025")
   for lines in z:
        header = header-20
        c.drawString(100, header, lines)
   c.save()

try:
    db = mysql.connector.connect(**config)
    cursor = db.cursor()
    print("\n-- Suppliers Delivery Variances --")
    cursor.execute("SELECT orders.Supplier_ID, AVG(DATEDIFF(orders.Expected_DeliveryDate, orders.Actual_DeliveryDate)) AS avg_variance_days, suppliers.supplier_name FROM orders INNER JOIN Suppliers ON orders.Supplier_ID = Suppliers.Supplier_ID GROUP BY Supplier_ID ORDER BY Supplier_ID;")
    orders = cursor.fetchall()
    x = []
    for orders in orders:
        x.append("Supplier " + str(orders[0]) + " " + str(orders[2] + " is " + str(orders[1])))

    print("\n-- Total Wine Sales by Distributor --")
    cursor.execute("SELECT distributors.distributor_ID, distributors.distributor_name, wine.wine_ID, wine.wine_name, SUM(wine_shipment.Total_Units) AS Total_Sales FROM wine_shipment INNER JOIN wine ON wine.wine_ID = wine_shipment.wine_ID INNER JOIN distributors ON distributors.distributor_ID = wine_shipment.distributor_ID GROUP BY distributors.distributor_ID, distributors.distributor_name, wine.wine_ID, wine.wine_name ORDER BY distributors.distributor_ID, wine.wine_ID;")
    distributors = cursor.fetchall()
    y = []
    for distributors in distributors:
        y.append("Total Sales of " + str(distributors[3]) + " from " + str(distributors[1]) + " is " + str(distributors[4]))

    print("\n-- Employee Hours in 2025 --")
    cursor.execute("SELECT employee_hours.employee_ID, employees.first_name, employees.last_name, SUM(employee_hours.monthly_hours) AS Total_Hours FROM employee_hours INNER JOIN employees ON employee_hours.employee_ID = employees.employee_ID GROUP BY employees.employee_ID ORDER BY employees.employee_ID;")
    employees = cursor.fetchall()
    z = []
    for employees in employees:
        z.append("Total Hours for " + str(employees[1]) + " " + str(employees[2]) + " are " + str(employees[3]))


except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print(" The supplied username or password are invalid")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print(" The specified database does not exist")
    else:
       print(err)
finally:
     db.close()

create_pdf_report("report.pdf")

